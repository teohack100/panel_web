<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../../includes/functions.php';
chkSession();
if($user_id_2 == 1 || $user_level_2 == 'superadmin'  || $user_level_2 == 'administrator'){
}else{
	echo '<script>alert("Sorry! You dont have Permission to Access this Page!...");</script>';
	$db->RedirectToURL($db->base_url());
	exit;
}

$regex = "((https?|ftp)\:\/\/)?"; // SCHEME
$regex .= "([a-z0-9+!*(),;?&=\$_.-]+(\:[a-z0-9+!*(),;?&=\$_.-]+)?@)?"; // User and Pass
$regex .= "([a-z0-9-.]*)\.([a-z]{2,4})"; // Host or IP
$regex .= "(\:[0-9]{2,5})?"; // Port
$regex .= "(\/([a-z0-9+\$_-]\.?)+)*\/?"; // Path
$regex .= "(\?[a-z+&\$_.-][a-z0-9;:@&%=+\/\$_.-]*)?"; // GET Query
$regex .= "(#[a-z_.-][a-z0-9+\$_.-]*)?"; // Anchor
$regex .= "(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"; //IPv4

if(isset($_POST['submitted']))
{
	if(empty($_POST['server_name'])){
		$db->HandleError("Empty Server Name");
		return false;
	}

	if(empty($_POST['server_category'])){
		$db->HandleError("Empty Server Category");
		return false;
	}

	if(empty($_POST['server_ip'])){
		$db->HandleError("Empty Server IP Address");
		return false;
	}

	if(empty($_POST['server_tcp'])){
		$db->HandleError("Empty Server TCP");
		return false;
	}

	if(preg_match('/^$regex$/', $_POST['server_ip'])){
		$db->HandleError("Invalid Server IP Address");
		return false;
	}

	$server_name = $db->Sanitize($_POST['server_name']);
	$server_category = $db->Sanitize($_POST['server_category']);
	$server_ip = $db->Sanitize($_POST['server_ip']);
	$server_port = $db->Sanitize($_POST['server_port']);
	$server_tcp = $db->Sanitize($_POST['server_tcp']);
	$server_folder = $db->Sanitize($_POST['server_folder']);
	if(empty($server_folder)){
		$folder = $server_folder;
		$server_folder = $server_folder;
	}else{
		$folder = $server_folder . '/';
		$server_folder = $server_folder;
	}
	$server_parser = 'http://'.$server_ip.':'.$server_port.'/'.$folder . $server_tcp.'.txt';

	$chk_server = $db->sql_query("SELECT server_name, server_ip FROM server_list WHERE server_ip='".$db->SanitizeForSQL($server_ip)."'");
	$server_row = $db->sql_fetchrow($chk_server);
	$db_server_name = $server_row['server_name'];
	$db_server_ip = $server_row['server_ip'];

	if($server_name != $db_server_name) {
		$u_result = $db->sql_query("SELECT server_name FROM server_list WHERE server_name='".$db->SanitizeForSQL($server_name)."'");
		if($db->sql_numrows($u_result) > 0) {
			$db->HandleError($server_name.' is already in our database!');
			//return false;
		}
	}

	if($server_ip != $db_server_ip) {
		$u_result = $db->sql_query("SELECT server_ip FROM server_list WHERE server_ip='".$db->SanitizeForSQL($server_ip)."'");
		if($db->sql_numrows($u_result) > 0) {
			$db->HandleError($server_ip.' is already in our database!');
			//return false;
		}
	}

	$submitted = $_POST['submitted'];
	if($submitted == 'Server Upload')
	{
		$sql_upload = "INSERT INTO server_list
		(server_name, server_ip, server_category, server_port, server_folder, server_tcp, server_parser, status)
		VALUES
		('".$db->SanitizeForSQL($server_name)."','".$db->SanitizeForSQL($server_ip)."','".$db->SanitizeForSQL($server_category)."',
		'".$db->SanitizeForSQL($server_port)."','".$db->SanitizeForSQL($server_folder)."','".$db->SanitizeForSQL($server_tcp)."','".$db->SanitizeForSQL($server_parser)."','1')
						   ";
		$upload = $db->sql_query($sql_upload);
		if($upload)
		{
			$db->HandleSuccess("Successfully Added New Server!...");
		}else{
			$db->HandleError("Sorry! Failed to add New Server!..");
		}
	}
	elseif($submitted == 'Server Edit')
	{
		$server_id = $db->Sanitize($_POST['server_id']);
		$sql_update = "UPDATE server_list SET
		server_name='".$server_name."',
		server_ip='".$server_ip."',
		server_folder='".$server_folder."',
		server_tcp='".$server_tcp."',
		server_port='".$server_port."',
		server_parser='".$server_parser."',
		server_category='".$server_category."'
		WHERE
		server_id='".$server_id."'
	   ";
		$update = $db->sql_query($sql_update);
		if($update)
		{
			$db->HandleSuccess("Successfully Updated Server!...");
		}else{
			$db->HandleError("Sorry! Failed to add New Server!..");
		}
	}else{
		$db->HandleError("Sorry! Invalid Server Upload!..");
	}
			
	echo $db->GetSuccessMessage();
	echo $db->GetErrorMessage();	
}else{
	if(empty($_POST['server_name'])){
		echo '<script> alert("Invalid Transaction"); </script>';
		$db->RedirectToURL($db->base_url().'404');
		exit;
	}

	if(empty($_POST['server_category'])){
		echo '<script> alert("Invalid Transaction"); </script>';
		$db->RedirectToURL($db->base_url().'404');
		exit;
	}

	if(empty($_POST['server_ip'])){
		echo '<script> alert("Invalid Transaction"); </script>';
		$db->RedirectToURL($db->base_url().'404');
		exit;
	}

	if(empty($_POST['server_port'])){
		echo '<script> alert("Invalid Transaction"); </script>';
		$db->RedirectToURL($db->base_url().'404');
		exit;
	}

	if(empty($_POST['server_tcp'])){
		echo '<script> alert("Invalid Transaction"); </script>';
		$db->RedirectToURL($db->base_url().'404');
		exit;
	}	
}
?>
