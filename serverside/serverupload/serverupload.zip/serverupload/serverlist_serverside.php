<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../../includes/functions.php';
chkSession();
if($user_id_2 == 1 || $user_level_2 == 'superadmin'  || $user_level_2 == 'administrator'){
}else{
	echo '<script>alert("Sorry! You dont have Permission to Access this Page!...");</script>';
	$db->RedirectToURL($db->base_url());
	exit;
}

$requestData= $_REQUEST;
if(empty($requestData)){
	echo '<script> alert("Invalid Transaction"); </script>';
	$db->RedirectToURL($db->base_url().'404');
	exit;
}

$columns = array( 
	0	=> 'server_id',
	1	=> 'server_name', 
	2	=> 'server_category',
	3	=> 'server_ip',
	4	=> 'server_port',
	5	=> 'status',
	6	=> null
);

$qry = "SELECT * FROM server_list";
$sql = $qry ." ORDER BY server_name ASC";
$query = $db->sql_query($sql) or die();
$totalData = $db->sql_numrows($query);
$totalFiltered = $totalData;
$sql = $qry ." WHERE 1=1 ";

if( !empty($requestData['search']['value']) ) { 
	$sql.=" AND ( server_id LIKE '%".$requestData['search']['value']."%' "; 
	$sql.=" OR server_name LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR server_category LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR server_port LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR server_ip LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR status LIKE '%".$requestData['search']['value']."%' ) ";
}

$query = $db->sql_query($sql) or die();
$totalFiltered = $db->sql_numrows($query);
$sql.="ORDER BY ". $columns[$requestData['order'][0]['column']]."  ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
$query = $db->sql_query($sql) or die();

$data = array();

while( $row = $db->sql_fetchrow($query) )
{
	$nestedData=array(); 
	$server_id = $row['server_id'];
	$server_name = $row['server_name'];
	$server_category = $row['server_category'];
	$server_ip = $row['server_ip'];
	$server_port = $row['server_port'];
	$server_folder = $row['server_folder'];
	if($row['status'] == 1)
	{
		$status = '<label class="label label-success">Online</label>';
	}else{
		$status = '<label class="label label-danger">Offline</label>';
	}
		
	$nestedData[] = '<input type="checkbox" name="chk[]" class="chk-box" value="'.$db->encryptor('encrypt',$server_id).'">';
	$nestedData[] = $server_name;
	$nestedData[] = $server_category;
	$nestedData[] = $server_ip;
	$nestedData[] = $server_port;
	$nestedData[] = $status;
	$nestedData[] = '<button type="button" class="btn btn-info" onclick="server_edit('.$server_id.')"><i class="glyphicon glyphicon-pencil"></i></button>';
		
	$data[] = $nestedData;
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] )? intval( $_REQUEST['draw'] ) : 0,
			"recordsTotal"    => intval( $totalData ),
			"recordsFiltered" => intval( $totalFiltered ),
			"data"            => ( $data )
			);
echo json_encode($json_data);
		
?>
