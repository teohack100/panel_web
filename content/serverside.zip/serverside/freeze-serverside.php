<?php
chkSession();
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'subadmin' || $user_level_2 == 'administrator' || $user_level_2 == 'reseller' || $user_level_2 == 'subreseller'){
	
}else{
	header("Location: /myaccount");	
}

$requestData= $_REQUEST;
if(empty($requestData)){
	$db->RedirectToURL($db->base_url());
	exit;	
}

$columns = array( 
	0	=> 'user_name', 
	1	=> 'duration',
	2	=> 'vip_duration',
	3	=> 'user_level',
	4	=> 'upline',
	5	=> 'last_freeze_date',
	6	=> null
);

$sql = "SELECT user_id, user_name, duration, vip_duration, credits, user_level, last_freeze_date, upline FROM users WHERE is_active=1 AND is_freeze=1 AND status='freeze' ORDER BY user_name ASC";
$query = $db->sql_query($sql) or die();
$totalData = $db->sql_numrows($query);
$totalFiltered = $totalData;
if($user_id_2 == 1 || $user_level_2 == 'superadmin'){
	$sql = "SELECT user_id, user_name, code, duration, vip_duration, credits, user_level, last_freeze_date, upline FROM users WHERE 1=1 AND is_active=1 AND is_freeze=1 AND status='freeze' ";
}else{
	$sql = "SELECT user_id, user_name, code, duration, vip_duration, credits, user_level, last_freeze_date, upline FROM users WHERE 1=1 AND upline='".$user_id_2."' AND is_active=1 AND is_freeze=1 AND status='freeze' ";
}

if( !empty($requestData['search']['value']) ) { 
	$sql.=" AND ( user_id LIKE '%".$requestData['search']['value']."%' "; 
	$sql.=" OR user_name LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR duration LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR vip_duration LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR credits LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR user_level LIKE '%".$requestData['search']['value']."%' ";
	$sql.=" OR upline LIKE '%".$requestData['search']['value']."%' ) ";
	$sql.=" OR last_freeze_date LIKE '%".$requestData['search']['value']."%' ) ";
}

$query = $db->sql_query($sql) or die();
$totalFiltered = $db->sql_numrows($query);
$sql.="ORDER BY ". $columns[$requestData['order'][0]['column']]."  ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

$query = $db->sql_query($sql) or die();


$data = array();
while( $row = $db->sql_fetchrow($query) ) {
	$nestedData=array();
	$id = $row['user_id'];
	$code = $row['code'];
	$credits = $row['credits'];
	if($row['duration'] == 0 && $row['vip_duration'] == 0 ){
		$user_name = '<font color="red">'.$row['user_name'].'</font>';
	}else{
		$user_name = '<font color="green">'.$row['user_name'].'</font>';
	}
		
	$dur = $db->calc_time($row['duration']);	
	if($row['duration'] == 0){
		$premuim_duration = "<font color='red'>". $dur['days'] . "</font> Day(s), <font color='red'>" . $dur['hours'] . "</font> Hour(s) and <font color='red'>" . $dur['minutes'] . "</font> Minutes Left.";
	}elseif($row['duration'] < 3600){
		$premuim_duration = "<font color='red'>". $dur['days'] . "</font> Day(s), <font color='red'>" . $dur['hours'] . "</font> Hour(s) and <font color='orange'>" . $dur['minutes'] . "</font> Minutes Left.";	
	}else{
		$premuim_duration = "<font color='green'>". $dur['days'] . "</font> Day(s), <font color='green'>" . $dur['hours'] . "</font> Hour(s) and <font color='green'>" . $dur['minutes'] . "</font> Minutes Left.";
	}
	
	$dur2 = $db->calc_time($row['vip_duration']);
	if($row['vip_duration'] == 0){
		$vip_duration = "<font color='red'>". $dur2['days'] . "</font> Day(s), <font color='red'>" . $dur2['hours'] . "</font> Hour(s) and <font color='red'>" . $dur2['minutes'] . "</font> Minutes Left.";
	}elseif($row['vip_duration'] < 3600){
		$vip_duration = "<font color='red'>". $dur2['days'] . "</font> Day(s), <font color='red'>" . $dur2['hours'] . "</font> Hour(s) and <font color='orange'>" . $dur2['minutes'] . "</font> Minutes Left.";	
	}else{
		$vip_duration = "<font color='green'>". $dur2['days'] . "</font> Day(s), <font color='green'>" . $dur2['hours'] . "</font> Hour(s) and <font color='green'>" . $dur2['minutes'] . "</font> Minutes Left.";
	}
	
	$dur3 = '<label class="label label-success">Premium:</label>'
			. $premuim_duration .'<br>'.'
			<label class="label label-success">VIP:</label>' 
			. $vip_duration;

	if($row['user_level'] == 'superadmin'){
		$user_level = 'Administrator';
	}
	else
	if($row['user_level'] == 'subadmin'){
		$user_level = 'Sub Administrator';
	}
	else
	if($row['user_level'] == 'administrator'){
		$user_level = 'administrator';
	}
	else
	if($row['user_level'] == 'reseller'){
		$user_level = 'Reseller';
	}
	else
	if($row['user_level'] == 'subreseller'){
		$user_level = 'Sub Reseller';
	}else{
		$user_level = 'Member';
	}
	$last_freeze_date = strtotime($row['last_freeze_date']);
	$date = date('F d, Y h:i A', $last_freeze_date);

	$select_qry = $db->sql_query("SELECT user_name FROM users WHERE user_id='".$row['upline']."'");
	$select_row = $db->sql_fetchrow($select_qry);
	
	$nestedData[] = $user_name;
	$nestedData[] = $dur3;
	$nestedData[] = $credits;
	$nestedData[] = $user_level;
	$nestedData[] = $date;
	$nestedData[] = '<a class="btn btn-block btn-info btn-sm"  href="javascript:void(0)" data-toggle="tooltip" title="View Account" onclick="view_info('.$id.','.$code.')">
						<i class="glyphicon glyphicon-file"></i></a> 

					 <a class="btn btn-block btn-success btn-sm"  href="javascript:void(0)" data-toggle="tooltip" title="Unfreeze Account"  onclick="unfreezed('.$id.','.$code.')">
						<i class="glyphicon glyphicon-play"></i></a>';

	$data[] = $nestedData;		
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] )? intval( $_REQUEST['draw'] ) : 0,
			"recordsTotal"    => intval( $totalData ),
			"recordsFiltered" => intval( $totalFiltered ),
			"data"            => ($data )
			);

echo json_encode($json_data);
?>