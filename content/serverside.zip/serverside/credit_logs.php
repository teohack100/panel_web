<?php
chkSession();
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'subadmin' || $user_level_2 == 'administrator' || $user_level_2 == 'reseller' || $user_level_2 == 'subreseller'){
	
}else{
	header("Location: /myaccount");	
}

$requestData= $_REQUEST;
if(empty($requestData)){
	$db->RedirectToURL($db->base_url());
	exit;	
}
$columns = array( 
	0	=> 'id',
	1	=> 'credits_username',
	2	=> 'credits_qty',
	3	=> 'credits_date',
	4	=> 'credits_id'
);

$sql = "SELECT * FROM credits_logs WHERE credits_id='".$user_id_2."' ORDER BY IF(credits_date = DATE(NOW()), 0, 1), credits_date DESC";
$query = $db->sql_query($sql) or die();
$totalData = $db->sql_numrows($query);
$totalFiltered = $totalData;

$sql = "SELECT * FROM credits_logs WHERE 1=1 AND credits_id='".$user_id_2."'";
if( !empty($requestData['search']['value']) ) {
	$sql.=" AND ( credits_username LIKE '%".$requestData['search']['value']."%' "; 
	$sql.=" OR credits_qty LIKE '%".$requestData['search']['value']."%' ) ";
}

$query = $db->sql_query($sql) or die();
$totalFiltered = $db->sql_numrows($query);

$sql.="ORDER BY ". $columns[$requestData['order'][0]['column']]."  ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

$query = $db->sql_query($sql) or die();


$data = array();
while( $row = $db->sql_fetchrow($query) ) {
	$nestedData=array(); 
	$id = $row['id'];
	$username = $row['credits_username'];
	$credits = $row['credits_qty'];
	$logs_date = strtotime($row['credits_date']);
	$date = date('F d, Y h:i', $logs_date);
	$elapse = $db->time_elapsed_string($logs_date);

	$nestedData[] = $username;
	$nestedData[] = $credits;
	$nestedData[] = $date;
	$nestedData[] = $elapse;
	
	$data[] = $nestedData;		
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] )? intval( $_REQUEST['draw'] ) : 0,
			"recordsTotal"    => intval( $totalData ),
			"recordsFiltered" => intval( $totalFiltered ),
			"data"            => ($data )
			);

echo json_encode($json_data);
?>